Interactive CAD Presentation
============================
Open index.html in a web browser (Chrome, Edge or Firefox).

- Everything the page needs is in this folder (images, parts.js with the 3D meshes).
- An internet connection is needed for the three.js 3D library and the fonts,
  which load from public CDNs (cdn.jsdelivr.net, fonts.googleapis.com).
- Keep all files in the same folder.
